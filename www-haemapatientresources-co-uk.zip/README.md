# heam-switchingkit-takeda
Static patient site for Takeda
